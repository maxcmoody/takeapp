const WINDOW_MS = 10 * 60 * 1000;
const MAX_REQUESTS = 30;

interface RateBucket {
  count: number;
  windowStart: number;
}

const buckets = new Map<string, RateBucket>();

setInterval(() => {
  const now = Date.now();
  const keys = Array.from(buckets.keys());
  for (const key of keys) {
    const bucket = buckets.get(key);
    if (bucket && now - bucket.windowStart > WINDOW_MS * 2) {
      buckets.delete(key);
    }
  }
}, 60_000);

export function getPlacesRateKey(userId?: string, ip?: string): string {
  return userId || ip || "anonymous";
}

export function checkPlacesRateLimit(key: string): { allowed: boolean; remaining: number; retryAfterMs: number } {
  const now = Date.now();
  let bucket = buckets.get(key);

  if (!bucket || now - bucket.windowStart >= WINDOW_MS) {
    bucket = { count: 0, windowStart: now };
    buckets.set(key, bucket);
  }

  if (bucket.count >= MAX_REQUESTS) {
    const retryAfterMs = WINDOW_MS - (now - bucket.windowStart);
    return { allowed: false, remaining: 0, retryAfterMs: Math.max(retryAfterMs, 0) };
  }

  bucket.count++;
  return { allowed: true, remaining: MAX_REQUESTS - bucket.count, retryAfterMs: 0 };
}
